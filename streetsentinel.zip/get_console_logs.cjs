const { Builder, By, until, logging } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

async function debug() {
  console.log("Setting up driver...");
  let options = new chrome.Options();
  options.addArguments('--ignore-certificate-errors');
  options.addArguments('--headless=new');
  options.addArguments('--no-sandbox');
  options.addArguments('--disable-dev-shm-usage');
  
  const prefs = new logging.Preferences();
  prefs.setLevel(logging.Type.BROWSER, logging.Level.ALL);
  options.setLoggingPrefs(prefs);

  let driver;
  try {
    driver = await new Builder()
      .forBrowser('chrome')
      .setChromeOptions(options)
      .build();
      
    console.log("Navigating to login page...");
    await driver.get('https://localhost:5173/login?role=citizen');
    
    console.log("Waiting for form inputs...");
    await driver.wait(until.elementLocated(By.css('input[type="email"]')), 5000);
    
    const emailInput = await driver.findElement(By.css('input[type="email"]'));
    const passwordInput = await driver.findElement(By.css('input[type="password"]'));
    
    await emailInput.sendKeys('roshinielumalai12@gmail.com');
    await passwordInput.sendKeys('123456');
    
    console.log("Submitting login form...");
    const submitBtn = await driver.findElement(By.css('button[type="submit"]'));
    await submitBtn.click();
    
    console.log("Waiting 8 seconds for response...");
    await driver.sleep(8000);
    
    console.log("Fetching browser logs...");
    const logs = await driver.manage().logs().get(logging.Type.BROWSER);
    console.log("--- BROWSER CONSOLE LOGS ---");
    logs.forEach(log => {
      console.log(`[${log.level.name}] ${log.message}`);
    });
    console.log("----------------------------");

  } catch (err) {
    console.error("Error occurred:", err);
  } finally {
    if (driver) {
      await driver.quit();
    }
  }
}

debug();

const { Builder, By, until } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');

async function test() {
  console.log("1. Setting up Chrome options...");
  let options = new chrome.Options();
  options.addArguments('--ignore-certificate-errors');
  options.addArguments('--no-sandbox');
  options.addArguments('--disable-dev-shm-usage');
  // Run headless to check if that succeeds
  options.addArguments('--headless');

  console.log("2. Building driver...");
  let driver;
  try {
    driver = await new Builder()
      .forBrowser('chrome')
      .setChromeOptions(options)
      .build();
    console.log("3. Driver built successfully.");
  } catch (err) {
    console.error("Failed to build driver:", err);
    return;
  }

  try {
    console.log("4. Navigating to https://localhost:5173/ ...");
    await driver.get('https://localhost:5173/');
    console.log("5. Page navigation completed.");
    
    console.log("6. Getting page title...");
    const title = await driver.getTitle();
    console.log("Page title is:", title);
  } catch (e) {
    console.error("Error during navigation/testing:", e);
  } finally {
    if (driver) {
      console.log("7. Quitting driver...");
      await driver.quit();
      console.log("8. Driver quit.");
    }
  }
}

test();

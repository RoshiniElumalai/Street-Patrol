import zipfile
import xml.etree.ElementTree as ET
import os

docx_path = r"C:\Users\ADMIN\Downloads\StreetSentinel_Edited_Patent_Document.docx"
txt_path = r"e:\street-patrol\StreetSentinel_Patent.txt"

def extract_text_from_docx(docx_file):
    try:
        with zipfile.ZipFile(docx_file) as z:
            xml_content = z.read('word/document.xml')
            root = ET.fromstring(xml_content)
            
            # Namespaces
            ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
            
            paragraphs = []
            for para in root.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'):
                text_elems = para.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t')
                text = ''.join([node.text for node in text_elems if node.text])
                if text:
                    paragraphs.append(text)
            
            return '\n'.join(paragraphs)
    except Exception as e:
        return f"Error: {e}"

text = extract_text_from_docx(docx_path)
with open(txt_path, 'w', encoding='utf-8') as f:
    f.write(text)

print(f"Text extracted successfully to {txt_path}")

const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const { initializeApp, getApps } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore } = require('firebase-admin/firestore');

async function prepare() {
  console.log("Preparing test user in Firebase (from server context)...");
  const email = "roshinielumalai12@gmail.com";
  const password = "123456";

  // Initialize Admin App if not already done
  let app;
  if (getApps().length === 0) {
    app = initializeApp({
      projectId: process.env.FIREBASE_PROJECT_ID || 'sos-street'
    });
  } else {
    app = getApps()[0];
  }

  const auth = getAuth(app);
  const db = getFirestore(app);

  try {
    let userRecord;
    try {
      userRecord = await auth.getUserByEmail(email);
      console.log(`User already exists in Firebase Auth: ${userRecord.uid}`);
    } catch (err) {
      if (err.code === 'auth/user-not-found') {
        console.log("User does not exist in Firebase Auth. Creating...");
        userRecord = await auth.createUser({
          email: email,
          password: password,
          displayName: "Roshini Elumalai",
          emailVerified: true
        });
        console.log(`User created successfully in Auth: ${userRecord.uid}`);
      } else {
        throw err;
      }
    }

    // Now verify/create user document in Firestore users collection
    const userDocRef = db.collection('users').doc(userRecord.uid);
    const userSnap = await userDocRef.get();
    
    if (!userSnap.exists) {
      console.log("Creating Firestore user document...");
      await userDocRef.set({
        name: "Roshini Elumalai",
        email: email,
        phone: "+919884293869",
        address: "Saveetha Nagar, Thandalam, Chennai",
        bloodGroup: "O+",
        role: "citizen",
        profileImage: "",
        registeredAt: new Date().toISOString()
      });
      console.log("Firestore user document created.");
    } else {
      console.log("Firestore user document already exists. Ensuring correct role...");
      await userDocRef.update({
        role: "citizen",
        name: "Roshini Elumalai"
      });
      console.log("Firestore user document verified.");
    }

    // Ensure they have at least one emergency contact
    const contactsColl = userDocRef.collection('contacts');
    const contactsSnap = await contactsColl.get();
    if (contactsSnap.empty) {
      console.log("Creating default emergency contact for user...");
      await contactsColl.add({
        name: "Dad (Home)",
        phone: "+919884293869",
        email: "patents.sdc@saveetha.com",
        relation: "Father"
      });
      console.log("Default emergency contact created.");
    } else {
      console.log("Emergency contacts verified.");
    }

    console.log("User preparation finished successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Error during user preparation:", error);
    process.exit(1);
  }
}

prepare();
